import { createRouter, createWebHistory } from 'vue-router';
import HomePage from '../components/HomePage.vue';
import AboutUs from '../components/AboutUs.vue';
import ContactUs from '../components/ContactUs.vue';
import ProductList from '../components/ProductList.vue';
import ShoppingCart from '../components/ShoppingCart.vue';
import UserLogin from '../components/UserLogin.vue';
import UserRegister from '../components/UserRegister.vue';
import UserMessages from '../components/UserMessages.vue';
import UserList from '../components/UserList.vue'; 

const routes = [
  { path: '/', component: HomePage },
  { path: '/about', component: AboutUs },
  { path: '/contact', component: ContactUs },
  { path: '/products', component: ProductList },
  { path: '/cart', component: ShoppingCart },
  { path: '/login', component: UserLogin, name: 'UserLogin' },
  { path: '/register', component: UserRegister, name: 'UserRegister' },
  { path: '/messages', component: UserMessages, name: 'UserMessages' },
  { path: '/users', component: UserList, name: 'UserList' }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
