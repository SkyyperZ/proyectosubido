<template>
  <div id="app">
    <nav class="navbar navbar-expand-lg navbar-dark bg-gradient-primary">
      <div class="container">
        <router-link to="/" class="navbar-brand">NEW ERA SHOP</router-link>
        <!-- Botón hamburguesa para móvil -->
        <button class="navbar-toggler" type="button" @click="toggleNavbar" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" :class="{ show: navbarOpen }" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <router-link to="/" class="nav-link">Inicio</router-link>
            </li>
            <li class="nav-item">
              <router-link to="/about" class="nav-link">Nosotros</router-link>
            </li>
            <li class="nav-item">
              <router-link to="/contact" class="nav-link">Contacto</router-link>
            </li>
            <li class="nav-item">
              <router-link to="/products" class="nav-link">Productos</router-link>
            </li>
            <li class="nav-item">
              <router-link to="/cart" class="nav-link">Carrito</router-link>
            </li>
            <li v-if="isAuthenticated && user.role === 'admin'" class="nav-item">
              <router-link to="/messages" class="nav-link">Mensajes</router-link>
            </li>
            <li v-if="isAuthenticated && user.role === 'admin'" class="nav-item">
              <router-link to="/users" class="nav-link">Usuarios</router-link>
            </li>
            <li v-if="!isAuthenticated" class="nav-item">
              <router-link to="/login" class="nav-link">Login</router-link>
            </li>
            <li v-if="!isAuthenticated" class="nav-item">
              <router-link to="/register" class="nav-link">Registro</router-link>
            </li>
            <li v-if="isAuthenticated" class="nav-item">
              <span class="nav-link">Hola, {{ user.name }} (Rol: {{ user.role }})</span>
            </li>
            <li v-if="isAuthenticated" class="nav-item">
              <button @click="logout" class="btn btn-link nav-link">Cerrar sesión</button>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="container mt-4">
      <div v-if="showCookieBanner" class="cookie-banner bg-light p-3 mb-3 border rounded">
        <p>
          Utilizamos cookies para asegurar que damos la mejor experiencia al usuario en nuestro sitio web. 
          Al continuar utilizando este sitio, asumiremos que estás de acuerdo con nuestra 
          <a href="/cookies-policy.html" class="text-primary">política de cookies</a>.
        </p>
        <div class="d-flex justify-content-center">
          <button class="btn btn-primary me-2" @click="acceptAllCookies">Aceptar todas las cookies</button>
          <button class="btn btn-secondary me-2" @click="acceptNecessaryCookies">Aceptar solo cookies necesarias</button>
          <button class="btn btn-danger" @click="rejectAllCookies">Rechazar todas las cookies</button>
        </div>
      </div>
      <router-view @login-success="handleLoginSuccess" :isAuthenticated="isAuthenticated" :user="user"></router-view>
    </div>
    <footer class="bg-dark text-light mt-5 py-4">
      <div class="container d-flex justify-content-between align-items-center">
        <div>
          <h5>Dirección:</h5>
          <p>C/ Limones 13, 23005, Jaén</p>
          <p>Tlf: 652001241</p>
        </div>
        <div>
          <h5>Síguenos en:</h5>
          <div class="d-flex">
            <a href="https://twitter.com" target="_blank" class="text-light me-3"><i class="fab fa-twitter fa-2x"></i></a>
            <a href="https://instagram.com" target="_blank" class="text-light me-3"><i class="fab fa-instagram fa-2x"></i></a>
            <a href="https://facebook.com" target="_blank" class="text-light me-3"><i class="fab fa-facebook fa-2x"></i></a>
            <a href="https://whatsapp.com" target="_blank" class="text-light me-3"><i class="fab fa-whatsapp fa-2x"></i></a>
          </div>
        </div>
        <div>
          <h5>Donde estamos:</h5>
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3162.6218933588564!2d-3.7882034846884397!3d37.76993751955769!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd6daff1a4f0d9bb%3A0x3b739f6e7b7fef58!2sC%2F%20Limones%2C%2013%2C%2023005%20Ja%C3%A9n%2C%20Spain!5e0!3m2!1sen!2sus!4v1629474869331!5m2!1sen!2sus" width="300" height="200" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
      </div>
      <div class="text-center mt-4">
        <p>Desarrollado por Ignacio Aguayo Lopez 2º DAW , Copyright 2024</p>
      </div>
    </footer>
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
      user: {},
      isAuthenticated: false,
      navbarOpen: false,
      showCookieBanner: true,
    };
  },
  created() {
    const user = JSON.parse(localStorage.getItem('user'));
    if (user) {
      this.user = user;
      this.isAuthenticated = true;
      this.loadUserCart();
    }
  },
  methods: {
    logout() {
      localStorage.removeItem('user');
      localStorage.removeItem('cart');
      this.isAuthenticated = false;
      this.$router.push('/login');
    },
    handleLoginSuccess(user) {
      this.user = user;
      this.isAuthenticated = true;
      this.loadUserCart();
    },
    async loadUserCart() {
      try {
        const response = await fetch('http://localhost/proyectofinal/get-cart.php', {
          method: 'GET',
          credentials: 'include'
        });
        const result = await response.json();
        if (result.success) {
          localStorage.setItem('cart', JSON.stringify(result.cart));
        } else {
          console.error('Error loading cart:', result.message);
        }
      } catch (error) {
        console.error('Error loading cart:', error);
      }
    },
    toggleNavbar() {
      this.navbarOpen = !this.navbarOpen;
    },
    acceptAllCookies() {
      this.showCookieBanner = false;
    },
    acceptNecessaryCookies() {
      this.showCookieBanner = false;
    },
    rejectAllCookies() {
      this.showCookieBanner = false;
    }
  }
};
</script>

<style>
/* importar todos los estilos  de booststrap*/
@import '~bootstrap/dist/css/bootstrap.css';

#app {
  font-family: 'Roboto', sans-serif;
  color: #333;
}

.navbar {
  border-bottom: 3px solid #007BFF;
}

.navbar-brand {
  font-weight: bold;
  color: #007BFF;
}

.navbar-brand:hover {
  color: #0056b3;
}

.navbar-toggler-icon {
  background-color: #007BFF;
}

.navbar-nav .nav-link {
  color: #fff;
}

.navbar-nav .nav-link:hover {
  color: #ddd;
}

.bg-gradient-primary {
  background-image: linear-gradient(120deg, #FF6F61, #007BFF);
}

footer {
  border-top: 3px solid #007BFF;
  background-color: #343a40;
}

footer h5 {
  color: #fff;
}

footer p {
  color: #ccc;
}

footer a {
  color: #ccc;
}

footer a:hover {
  color: #fff;
}

footer i {
  margin-right: 15px;
}

footer iframe {
  border: 0;
  width: 100%;
  height: 200px;
}

footer .text-center {
  margin-top: 20px;
}

footer .text-center p {
  margin: 0;
}

.cookie-banner {
  position: fixed;
  bottom: 0;
  width: 100%;
  left: 50%;
  transform: translateX(-50%);
  z-index: 1000;
  box-shadow: 0 -2px 5px rgba(0,0,0,0.2);
  background-color: #fff;
}

.cookie-banner p {
  margin-bottom: 0.5rem;
}

.cookie-banner .btn {
  margin: 0.25rem;
}
</style>
