<template>
  <div class="container mt-5">
    <h2 class="text-center mb-4">Lista de Productos</h2>

    <div class="engagement-texts mb-4">
      <h4 class="text-center text-primary">¿Quieres convertirte en un experto en marketing digital? ¡Nuestros cursos te lo permiten!</h4>
      <p class="text-center text-secondary">Aprende de los mejores profesionales y consigue tu certificado oficial en tan solo 6 meses.</p>
    </div>

    <div class="search-bar mb-4">
      <input type="text" v-model="searchQuery" class="form-control" placeholder="Buscar productos por nombre" />
    </div>

    <div v-if="isAuthenticated && user.role === 'admin'">
      <button class="btn btn-primary mb-3" @click="toggleAddProductForm">Agregar Producto</button>
    </div>

    <div class="modal fade" id="productFormModal" tabindex="-1" aria-labelledby="productFormModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header bg-primary text-light">
            <h5 class="modal-title" id="productFormModalLabel">{{ editingProduct ? 'Editar Producto' : 'Agregar Nuevo Producto' }}</h5>
            <button type="button" class="btn-close text-light" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="saveProduct">
              <div class="mb-3">
                <label for="productName" class="form-label">Nombre:</label>
                <input type="text" v-model="currentProduct.name" class="form-control" id="productName" required>
              </div>
              <div class="mb-3">
                <label for="productPrice" class="form-label">Precio:</label>
                <input type="number" v-model.number="currentProduct.price" step="0.01" class="form-control" id="productPrice" required>
              </div>
              <div class="mb-3">
                <label for="productQuantity" class="form-label">Cantidad:</label>
                <input type="number" v-model.number="currentProduct.quantity" class="form-control" id="productQuantity" required>
              </div>
              <div class="mb-3" v-if="!editingProduct">
                <label for="productCode" class="form-label">Código de Producto:</label>
                <input type="text" v-model="currentProduct.codeProduct" class="form-control" id="productCode" required @blur="checkProductCode">
                <div v-if="codeProductError" class="text-danger">{{ codeProductError }}</div>
              </div>
              <div class="mb-3" v-else>
                <label for="productCode" class="form-label">Código de Producto:</label>
                <input type="text" v-model="currentProduct.codeProduct" class="form-control" id="productCode" required>
              </div>
              <div class="mb-3">
                <label for="productDescription" class="form-label">Descripción:</label>
                <textarea v-model="currentProduct.description" class="form-control" id="productDescription" rows="3" required></textarea>
              </div>
              <div class="mb-3">
                <label for="productVideo" class="form-label">URL del Video:</label>
                <input type="text" v-model="currentProduct.video" class="form-control" id="productVideo" required>
              </div>
              <div class="mb-3">
                <label for="productImage" class="form-label">URL de la Imagen:</label>
                <input type="text" v-model="currentProduct.image" class="form-control" id="productImage" required>
              </div>
              <button type="submit" class="btn btn-primary btn-block">{{ editingProduct ? 'Actualizar' : 'Agregar' }}</button>
            </form>
          </div>
        </div>
      </div>
    </div>

    <div v-if="errorMessage" class="alert alert-danger mt-3" role="alert">
      {{ errorMessage }}
    </div>

    <div class="row">
      <div class="col-lg-4 col-md-6 mb-4" v-for="(product, index) in filteredProducts" :key="index">
        <div class="card h-100 bg-light rounded shadow-sm">
          <div class="card-body d-flex flex-column">
            <div class="mb-3">
              <img :src="product.image" alt="Imagen del producto" class="img-fluid" style="width: 100%; height: 150px; object-fit: cover;">
            </div>
            <div class="flex-grow-1">
              <h5 class="card-title">{{ product.name }}</h5>
              <p class="card-text">{{ product.price }} €</p>
              <div class="d-flex justify-content-between">
                <button class="btn btn-primary btn-sm me-2" @click="openProductModal(product)">Ver Detalles</button>
                <button v-if="isAuthenticated && user.role !== 'admin'" class="btn btn-success btn-sm" @click="addToCart(product)">Añadir al Carrito</button>
              </div>
              <div v-if="isAuthenticated && user.role === 'admin'" class="d-flex gap-2 mt-2">
                <button class="btn btn-success btn-sm" @click="editProduct(product)">Modificar</button>
                <button class="btn btn-danger btn-sm" @click="deleteProductConfirmed(product)">Borrar</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de Detalles del Producto -->
    <div class="modal fade" id="productModal" tabindex="-1" role="dialog" aria-labelledby="productModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header bg-primary text-light">
            <h5 class="modal-title" id="productModalLabel">Detalles del Producto</h5>
            <button type="button" class="btn-close text-light" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body text-center">
            <img :src="selectedProduct?.image" alt="Imagen del producto" class="img-fluid mb-3">
            <p><strong>Nombre:</strong> {{ selectedProduct?.name }}</p>
            <p><strong>Precio:</strong> {{ selectedProduct?.price }} €</p>
            <p v-if="user.role === 'admin'"><strong>Cantidad:</strong> {{ selectedProduct?.quantity }}</p>
            <p><strong>Código:</strong> {{ selectedProduct?.codeProduct }}</p>
            <p><strong>Descripción:</strong> {{ selectedProduct?.description }}</p>
            <button class="btn btn-info" @click="openProductVideo(selectedProduct?.video)">Ver Video</button>
          </div>
          <div class="modal-footer bg-light">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de Login -->
    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header bg-primary text-light">
            <h5 class="modal-title" id="loginModalLabel">Inicia sesión o regístrate</h5>
            <button type="button" class="btn-close text-light" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p>Para añadir productos al carrito, necesitas iniciar sesión o registrarte.</p>
            <div class="d-flex justify-content-between">
              <button class="btn btn-primary" @click="redirectToLogin">Iniciar sesión</button>
              <button class="btn btn-secondary" @click="redirectToRegister">Registrarse</button>
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>
</template>

<script>
import { Modal } from 'bootstrap';

export default {
  name: 'ProductList',
  props: ['isAuthenticated', 'user'],
  data() {
    return {
      currentProduct: {
        id: null,
        name: '',
        price: 0,
        quantity: 0,
        codeProduct: '',
        description: '',
        video: '',
        image: ''
      },
      editingProduct: false,
      errorMessage: '',
      codeProductError: '',
      products: [],
      selectedProduct: null,
      searchQuery: ''  
    };
  },
  computed: {
    filteredProducts() {
      return this.products.filter(product =>
        product.name.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    }
  },
  methods: {
    toggleAddProductForm() {
      this.resetForm();
      this.editingProduct = false;
      const modal = new Modal(document.getElementById('productFormModal'));
      modal.show();
    },
    resetForm() {
      this.currentProduct = { id: null, name: '', price: 0, quantity: 0, codeProduct: '', description: '', video: '', image: '' };
      this.codeProductError = '';
      this.errorMessage = '';
    },
    async checkProductCode() {
      if (this.editingProduct) return;
      this.codeProductError = '';
      const codeProduct = this.currentProduct.codeProduct;

      try {
        const response = await fetch('http://localhost/proyectofinal/check-product-code.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ code: codeProduct })
        });

        const result = await response.json();
        if (result.exists) {
          this.codeProductError = 'Este código de producto ya está en uso.';
        }
      } catch (error) {
        this.codeProductError = 'Error al verificar el código del producto.';
      }
    },
    async saveProduct() {
      this.errorMessage = '';
      if (this.codeProductError) {
        return;
      }

      try {
        if (this.editingProduct) {
          await this.updateProduct();
        } else {
          await this.addProduct();
        }
      } catch (error) {
        this.errorMessage = 'Error al enviar la solicitud: ' + error.message;
      }
    },
    async addProduct() {
      try {
        const response = await fetch('http://localhost/proyectofinal/add-product.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(this.currentProduct)
        });

        const result = await response.json();
        if (response.ok && result.success) {
          await this.fetchProducts();
          this.resetForm();
          const modal = Modal.getInstance(document.getElementById('productFormModal'));
          modal.hide();
        } else {
          this.errorMessage = result.message || 'Error al agregar el producto';
        }
      } catch (error) {
        this.errorMessage = 'Error al enviar la solicitud: ' + error.message;
      }
    },
    async updateProduct() {
      try {
        const response = await fetch('http://localhost/proyectofinal/update-product.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(this.currentProduct)
        });

        const result = await response.json();
        if (response.ok && result.success) {
          await this.fetchProducts();
          this.resetForm();
          const modal = Modal.getInstance(document.getElementById('productFormModal'));
          modal.hide();
        } else {
          this.errorMessage = result.message || 'Error al actualizar el producto';
        }
      } catch (error) {
        this.errorMessage = 'Error al enviar la solicitud: ' + error.message;
      }
    },
    editProduct(product) {
      this.editingProduct = true;
      this.currentProduct = { ...product };
      const modal = new Modal(document.getElementById('productFormModal'));
      modal.show();
    },
    async deleteProductConfirmed(product) {
      try {
        const response = await fetch('http://localhost/proyectofinal/delete-product.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ id: product.id })
        });

        const result = await response.json();
        if (response.ok && result.success) {
          await this.fetchProducts();
        } else {
          this.errorMessage = result.message || 'Error al borrar el producto';
        }
      } catch (error) {
        this.errorMessage = 'Error al enviar la solicitud: ' + error.message;
      }
    },
    async fetchProducts() {
      try {
        const response = await fetch('http://localhost/proyectofinal/get-products.php');
        if (response.ok) {
          const data = await response.json();
          this.products = data.map(product => ({ ...product, selectedQuantity: 1 }));
        } else {
          this.errorMessage = 'Error al obtener la lista de productos';
        }
      } catch (error) {
        this.errorMessage = 'Error al enviar la solicitud: ' + error.message;
      }
    },
    addToCart(product) {
      if (!this.isAuthenticated) {
        this.showLoginModal();
        return;
      }
      const cart = JSON.parse(localStorage.getItem('cart')) || [];
      const productIndex = cart.findIndex(item => item.id === product.id);

      if (productIndex !== -1) {
        cart[productIndex].quantity += 1;
      } else {
        cart.push({ ...product, quantity: 1 });
      }

      localStorage.setItem('cart', JSON.stringify(cart));
      alert('Producto añadido al carrito');
    },
    openProductModal(product) {
      this.selectedProduct = product;
      const modal = new Modal(document.getElementById('productModal'));
      modal.show();
    },
    openProductVideo(videoUrl) {
      window.open(videoUrl, '_blank');
    },
    showLoginModal() {
      const modal = new Modal(document.getElementById('loginModal'));
      modal.show();
    },
    redirectToLogin() {
      const modal = Modal.getInstance(document.getElementById('loginModal'));
      modal.hide();
      this.$router.push('/login');
    },
    redirectToRegister() {
      const modal = Modal.getInstance(document.getElementById('loginModal'));
      modal.hide();
      this.$router.push('/register');
    }
  },
  created() {
    this.fetchProducts();
  }
};
</script>


