<template>
  <div class="container mt-5">
    <h2 class="text-center mb-4">Lista de Usuarios</h2>
    <div v-if="users.length === 0" class="text-center">
      <p>No hay usuarios disponibles</p>
    </div>
    <div v-else>
      <div class="card mb-3" v-for="(user, index) in users" :key="index">
        <div class="card-header d-flex justify-content-between align-items-center">
          <h5 class="mb-0">{{ user.first_name }} {{ user.last_name }}</h5>
          <div>
            <button class="btn btn-primary btn-sm me-2" @click="viewUser(user)">Ver Detalles</button>
            <button class="btn btn-warning btn-sm me-2" @click="editUser(user)">Modificar</button>
            <button class="btn btn-danger btn-sm" @click="confirmDelete(user)">Eliminar</button>
          </div>
        </div>
        <div class="card-body">
          <p><strong>Email:</strong> {{ user.email }}</p>
          <p><strong>Teléfono:</strong> {{ user.phone }}</p>
          <p><strong>Rol:</strong> {{ user.role }}</p>
        </div>
      </div>
    </div>

    <!-- Modal de Detalles del Usuario -->
    <div class="modal fade" id="userModal" tabindex="-1" aria-labelledby="userModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header bg-primary text-light">
            <h5 class="modal-title" id="userModalLabel">Detalles del Usuario</h5>
            <button type="button" class="btn-close text-light" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body" v-if="selectedUser">
            <p><strong>Nombre:</strong> {{ selectedUser.first_name }} {{ selectedUser.last_name }}</p>
            <p><strong>Email:</strong> {{ selectedUser.email }}</p>
            <p><strong>Teléfono:</strong> {{ selectedUser.phone }}</p>
            <p><strong>Rol:</strong> {{ selectedUser.role }}</p>
            <div v-if="selectedUser.role === 'admin'">
              <p><strong>Empresa:</strong> {{ selectedUser.company_name }}</p>
              <p><strong>Dirección:</strong> {{ selectedUser.company_address }}</p>
              <p><strong>CIF:</strong> {{ selectedUser.company_cif }}</p>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de Confirmación de Eliminación -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header bg-danger text-light">
            <h5 class="modal-title" id="deleteModalLabel">Confirmar Eliminación</h5>
            <button type="button" class="btn-close text-light" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p v-if="selectedUser">¿Estás seguro de que deseas eliminar al usuario {{ selectedUser.first_name }} {{ selectedUser.last_name }}?</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="button" class="btn btn-danger" @click="deleteUser">Eliminar</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de Modificación del Usuario -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header bg-warning text-dark">
            <h5 class="modal-title" id="editModalLabel">Modificar Usuario</h5>
            <button type="button" class="btn-close text-dark" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body" v-if="selectedUser">
            <form @submit.prevent="updateUser">
              <div class="mb-3">
                <label for="first_name" class="form-label">Nombre</label>
                <input type="text" class="form-control" id="first_name" v-model="selectedUser.first_name" required>
              </div>
              <div class="mb-3">
                <label for="last_name" class="form-label">Apellidos</label>
                <input type="text" class="form-control" id="last_name" v-model="selectedUser.last_name" required>
              </div>
              <div class="mb-3">
                <label for="phone" class="form-label">Teléfono</label>
                <input type="text" class="form-control" id="phone" v-model="selectedUser.phone" required>
              </div>
              <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" v-model="selectedUser.email" required>
              </div>
              <button type="submit" class="btn btn-warning">Actualizar</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Modal } from 'bootstrap';

export default {
  name: 'UserList',
  data() {
    return {
      users: [],
      selectedUser: null,
    };
  },
  methods: {
    async fetchUsers() {
      try {
        const response = await fetch('http://localhost/proyectofinal/get-users.php');
        if (response.ok) {
          this.users = await response.json();
        } else {
          console.error('Error al obtener los usuarios');
        }
      } catch (error) {
        console.error('Error al enviar la solicitud', error);
      }
    },
    viewUser(user) {
      this.selectedUser = user;
      const modal = new Modal(document.getElementById('userModal'));
      modal.show();
    },
    confirmDelete(user) {
      this.selectedUser = user;
      const modal = new Modal(document.getElementById('deleteModal'));
      modal.show();
    },
    async deleteUser() {
      try {
        const response = await fetch('http://localhost/proyectofinal/delete-user.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ id: this.selectedUser.id })
        });

        const result = await response.json();
        if (result.success) {
          this.fetchUsers();
          const modal = Modal.getInstance(document.getElementById('deleteModal'));
          modal.hide();
        } else {
          console.error('Error al eliminar el usuario', result.message);
        }
      } catch (error) {
        console.error('Error al enviar la solicitud', error);
      }
    },
    editUser(user) {
      this.selectedUser = { ...user }; // Hacer una copia del usuario
      const modal = new Modal(document.getElementById('editModal'));
      modal.show();
    },
    async updateUser() {
      try {
        const response = await fetch('http://localhost/proyectofinal/update-user.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(this.selectedUser)
        });

        const result = await response.json();
        if (result.success) {
          this.fetchUsers();
          const modal = Modal.getInstance(document.getElementById('editModal'));
          modal.hide();
        } else {
          console.error('Error al actualizar el usuario', result.message);
        }
      } catch (error) {
        console.error('Error al enviar la solicitud', error);
      }
    }
  },
  created() {
    this.fetchUsers();
  }
};
</script>

<style scoped>
.container {
  margin-top: 50px;
}

h2 {
  color: #007bff;
  font-weight: bold;
}

.card {
  border-radius: 10px;
  transition: transform 0.3s, box-shadow 0.3s;
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.card-header {
  background-color: #007bff;
  color: #fff;
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
}

.card-header h5 {
  margin: 0;
}

.btn-primary {
  background-color: #007bff;
  border: none;
}

.btn-primary:hover {
  background-color: #0056b3;
}

.btn-warning {
  background-color: #ffc107;
  border: none;
}

.btn-warning:hover {
  background-color: #e0a800;
}

.btn-danger {
  background-color: #dc3545;
  border: none;
}

.btn-danger:hover {
  background-color: #c82333;
}

.modal-content {
  border-radius: 10px;
}

.modal-header {
  background-color: #007bff;
}

.btn-close {
  background-color: transparent;
  border: none;
  color: #fff;
}

.btn-secondary {
  background-color: #6c757d;
  border: none;
}

.btn-secondary:hover {
  background-color: #545b62;
}
</style>
