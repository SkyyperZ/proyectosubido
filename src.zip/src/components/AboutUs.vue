<template>
  <div class="about-us container mt-5">
    <div class="text-center mb-5">
      <h1 class="display-4">Sobre Nosotros</h1>
      <p class="lead">Descubre nuestra historia y lo que nos impulsa a ofrecerte lo mejor en formación online.</p>
    </div>
    <div class="row">
      <div class="col-md-6">
        <img src="https://raw.githubusercontent.com/SkyyperZ/proyectofinal/main/all.webp" class="img-fluid rounded shadow" alt="Nuestro equipo">
      </div>
      <div class="col-md-6">
        <h2>Quiénes Somos</h2>
        <p>En <strong>New Era Shop</strong>, somos un equipo apasionado por la educación y la tecnología. Nuestra misión es proporcionar cursos de alta calidad en marketing digital, programación, SEO y manejo de redes sociales, capacitando a nuestros estudiantes para alcanzar el éxito en sus carreras.</p>
        <p>Desde nuestros humildes comienzos, hemos crecido hasta convertirnos en una referencia en la formación online, con miles de estudiantes satisfechos que han transformado sus vidas profesionales gracias a nuestros cursos.</p>
        <h2>Nuestra Misión</h2>
        <p>Queremos democratizar el acceso a la educación de calidad, ofreciendo cursos accesibles y actualizados que permitan a nuestros estudiantes desarrollar habilidades clave para el mundo digital de hoy.</p>
        <h2>Por Qué Elegirnos</h2>
        <ul>
          <li><strong>Expertos en la materia:</strong> Nuestros instructores son profesionales experimentados en sus campos.</li>
          <li><strong>Flexibilidad:</strong> Aprende a tu propio ritmo, desde cualquier lugar y en cualquier momento.</li>
          <li><strong>Actualizaciones constantes:</strong> Nuestros cursos se actualizan regularmente para incluir las últimas tendencias y tecnologías.</li>
        </ul>
      </div>
    </div>
    <div class="row mt-5">
      <div class="col-md-4 text-center">
        <i class="fa fa-graduation-cap fa-3x mb-3"></i>
        <h4>Formación de Calidad</h4>
        <p>Cursos diseñados por expertos para garantizar tu éxito profesional.</p>
      </div>
      <div class="col-md-4 text-center">
        <i class="fa fa-laptop fa-3x mb-3"></i>
        <h4>Acceso 24/7</h4>
        <p>Accede a nuestros cursos en cualquier momento y desde cualquier lugar.</p>
      </div>
      <div class="col-md-4 text-center">
        <i class="fa fa-thumbs-up fa-3x mb-3"></i>
        <h4>Satisfacción Garantizada</h4>
        <p>Tu éxito es nuestra prioridad. Nos esforzamos por brindarte la mejor experiencia de aprendizaje.</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'AboutUs',
};
</script>

<style scoped>
.container {
  margin-top: 50px;
  background: #f9f9f9;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.text-center {
  text-align: center;
}

h1.display-4 {
  font-weight: 700;
  color: #007bff;
}

.lead {
  font-size: 1.25rem;
  font-weight: 300;
  color: #6c757d;
}

h2 {
  font-weight: 600;
  color: #333;
}

ul {
  padding-left: 20px;
}

ul li {
  margin-bottom: 10px;
}

.fa {
  color: #007bff;
}

.img-fluid {
  border-radius: 10px;
}

@media (max-width: 768px) {
  .col-md-6, .col-md-4 {
    margin-bottom: 20px;
  }
}
</style>
