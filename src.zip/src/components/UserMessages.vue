<template>
  <div class="container mt-5">
    <h2 class="text-center mb-4">Mensajes</h2>
    <div v-if="messages.length === 0" class="text-center">
      <p>No hay mensajes disponibles</p>
    </div>
    <div v-else>
      <div class="card mb-3" v-for="(message, index) in messages" :key="index">
        <div class="card-header d-flex justify-content-between align-items-center">
          <h5 class="mb-0">{{ message.subject }}</h5>
          <div>
            <button class="btn btn-primary btn-sm me-2" @click="viewMessage(message)">Ver Detalles</button>
            <button class="btn btn-danger btn-sm" @click="deleteMessage(message.id)">Eliminar</button>
          </div>
        </div>
        <div class="card-body">
          <p><strong>Nombre:</strong> {{ message.name }} {{ message.surname }}</p>
          <p><strong>Email:</strong> {{ message.email }}</p>
        </div>
      </div>
    </div>

    <!-- Modal de Detalles del Mensaje -->
    <div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header bg-primary text-light">
            <h5 class="modal-title" id="messageModalLabel">Detalles del Mensaje</h5>
            <button type="button" class="btn-close text-light" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p><strong>Nombre:</strong> {{ selectedMessage?.name }} {{ selectedMessage?.surname }}</p>
            <p><strong>Teléfono:</strong> {{ selectedMessage?.phone }}</p>
            <p><strong>Email:</strong> {{ selectedMessage?.email }}</p>
            <p><strong>Rol:</strong> {{ selectedMessage?.role }}</p>
            <p v-if="selectedMessage?.role === 'admin'"><strong>Empresa:</strong> {{ selectedMessage?.company_name }}</p>
            <p><strong>Asunto:</strong> {{ selectedMessage?.subject }}</p>
            <p><strong>Mensaje:</strong></p>
            <p>{{ selectedMessage?.message }}</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Modal } from 'bootstrap';

export default {
  name: 'UserMessages',
  data() {
    return {
      messages: [],
      selectedMessage: null,
    };
  },
  methods: {
    async fetchMessages() {
      try {
        const response = await fetch('http://localhost/proyectofinal/get-messages.php');
        if (response.ok) {
          this.messages = await response.json();
        } else {
          console.error('Error al obtener los mensajes');
        }
      } catch (error) {
        console.error('Error al enviar la solicitud', error);
      }
    },
    async deleteMessage(id) {
      try {
        const response = await fetch('http://localhost/proyectofinal/delete-message.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ id })
        });

        const result = await response.json();
        if (result.success) {
          this.messages = this.messages.filter(message => message.id !== id);
        } else {
          console.error('Error al eliminar el mensaje:', result.message);
        }
      } catch (error) {
        console.error('Error al enviar la solicitud', error);
      }
    },
    viewMessage(message) {
      this.selectedMessage = message;
      const modal = new Modal(document.getElementById('messageModal'));
      modal.show();
    }
  },
  created() {
    this.fetchMessages();
  }
};
</script>

<style scoped>
.container {
  margin-top: 50px;
}

h2 {
  color: #007bff;
  font-weight: bold;
}

.card {
  border-radius: 10px;
  transition: transform 0.3s, box-shadow 0.3s;
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.card-header {
  background-color: #007bff;
  color: #fff;
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
}

.card-header h5 {
  margin: 0;
}

.btn-primary {
  background-color: #007bff;
  border: none;
}

.btn-primary:hover {
  background-color: #0056b3;
}

.btn-danger {
  background-color: #dc3545;
  border: none;
}

.btn-danger:hover {
  background-color: #c82333;
}

.modal-content {
  border-radius: 10px;
}

.modal-header {
  background-color: #007bff;
}

.btn-close {
  background-color: transparent;
  border: none;
  color: #fff;
}

.btn-secondary {
  background-color: #6c757d;
  border: none;
}

.btn-secondary:hover {
  background-color: #545b62;
}
</style>
