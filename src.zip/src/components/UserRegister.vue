<template>
  <div class="container mt-5">
    <h1 class="text-primary text-center">Registro</h1>
    <form @submit.prevent="submitForm" class="needs-validation">
      <div class="form-group">
        <label for="firstName" class="text-info">Nombre:</label>
        <input type="text" v-model="firstName" class="form-control" id="firstName" required :class="{ 'is-invalid': !firstName, 'is-valid': firstName && isFirstNameValid }" @keypress="validateNameInput">
        <div class="invalid-feedback text-danger" v-if="!firstName">El nombre es obligatorio</div>
      </div>
      <div class="form-group">
        <label for="lastName" class="text-info">Apellidos:</label>
        <input type="text" v-model="lastName" class="form-control" id="lastName" required :class="{ 'is-invalid': !lastName, 'is-valid': lastName && isLastNameValid }" @keypress="validateNameInput">
        <div class="invalid-feedback text-danger" v-if="!lastName">Los apellidos son obligatorios</div>
      </div>
      <div class="form-group">
        <label for="phone" class="text-info">Teléfono de contacto:</label>
        <input type="text" v-model="phone" class="form-control" id="phone" required :class="{ 'is-invalid': !phone, 'is-valid': phone && isPhoneValid }">
        <div class="invalid-feedback text-danger" v-if="!phone">El teléfono es obligatorio</div>
      </div>
      <div class="form-group">
        <label for="email" class="text-info">Email de contacto:</label>
        <input type="email" v-model="email" class="form-control" id="email" required :class="{ 'is-invalid': !email, 'is-valid': email && isEmailValid }">
        <div class="invalid-feedback text-danger" v-if="!email">El email es obligatorio</div>
      </div>
      <div class="form-group">
        <label for="password" class="text-info">Contraseña:</label>
        <div class="input-group">
          <input :type="showPassword ? 'text' : 'password'" v-model="password" class="form-control" id="password" required autocomplete="current-password" :class="{ 'is-invalid': !password, 'is-valid': password && isPasswordValid }">
          <div class="input-group-append">
            <button type="button" class="btn btn-secondary" @click="generatePassword">Generar Contraseña</button>
          </div>
          <div class="input-group-append">
            <!-- Boton de ver la contraseña u ocultarla-->
            <button type="button" class="btn btn-outline-secondary" @click="togglePasswordVisibility">
              <i :class="['fa', showPassword ? 'fa-eye-slash' : 'fa-eye']"></i>
            </button>
          </div>
        </div>
        <div class="invalid-feedback text-danger" v-if="!password">La contraseña es obligatoria</div>
      </div>
      <div class="form-group">
        <label for="role" class="text-info">Rol:</label>
        <select v-model="role" class="form-control" id="role" required :class="{ 'is-invalid': !role, 'is-valid': role }">
          <option value="particular">Particular</option>
          <option value="admin">Admin</option>
        </select>
        <div class="invalid-feedback text-danger" v-if="!role">El rol es obligatorio</div>
      </div>
      <div v-if="role === 'admin'">
        <div class="form-group">
          <label for="companyName" class="text-info">Nombre de la empresa:</label>
          <input type="text" v-model="companyName" class="form-control" id="companyName" required :class="{ 'is-invalid': !companyName, 'is-valid': companyName }">
          <div class="invalid-feedback text-danger" v-if="!companyName">El nombre de la empresa es obligatorio</div>
        </div>
        <div class="form-group">
          <label for="companyAddress" class="text-info">Dirección de las oficinas:</label>
          <input type="text" v-model="companyAddress" class="form-control" id="companyAddress" required :class="{ 'is-invalid': !companyAddress, 'is-valid': companyAddress }">
          <div class="invalid-feedback text-danger" v-if="!companyAddress">La dirección de las oficinas es obligatoria</div>
        </div>
        <div class="form-group">
          <label for="companyCIF" class="text-info">CIF:</label>
          <input type="text" v-model="companyCIF" class="form-control" id="companyCIF" required :class="{ 'is-invalid': !companyCIF, 'is-valid': companyCIF && isCIFValid }">
          <div class="invalid-feedback text-danger" v-if="!companyCIF">El CIF es obligatorio</div>
        </div>
      </div>
      <button type="submit" class="btn btn-primary" :disabled="!isFormValid">Registrar</button>
      <div v-if="successMessage" class="alert alert-success mt-3" role="alert">{{ successMessage }}</div>
      <div v-if="errorMessage" class="alert alert-danger mt-3" role="alert" v-html="errorMessage"></div>
    </form>

    <!-- Cuadrado con botones -->
    <div class="mt-3">
      <div class="alert alert-secondary" role="alert">
        <p class="text-primary">¿Ya tienes una cuenta?</p>
        <button class="btn btn-primary mr-2" @click="goToLogin">Ir al Login</button>
      </div>
    </div>

    <!-- Modal de éxito -->
    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header bg-success text-light">
            <h5 class="modal-title" id="successModalLabel">Registro Exitoso</h5>
            <button type="button" class="btn-close text-light" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body text-center">
            <i class="fa fa-check-circle fa-3x text-success mb-3"></i>
            <p>Usuario registrado con éxito.</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Modal } from 'bootstrap';

export default {
  name: 'UserRegister',
  data() {
    return {
      firstName: '',
      lastName: '',
      phone: '',
      email: '',
      password: '',
      role: 'particular',
      companyName: '',
      companyAddress: '',
      companyCIF: '',
      showPassword: false,
      successMessage: '',
      errorMessage: ''
    };
  },
  /* Comprobaciones */
  computed: {
    isFirstNameValid() {
      return this.firstName.trim() !== '';
    },
    isLastNameValid() {
      return this.lastName.trim() !== '';
    },
    isPhoneValid() {
      return /^\d{9}$/.test(this.phone);
    },
    isEmailValid() {
      return /\S+@\S+\.\S+/.test(this.email);
    },
    isPasswordValid() {
      return /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z\d!@#$%^&*()_+]{12,18}$/.test(this.password);
    },
    isCIFValid() {
      return /^[0-9]{7}[A-Za-z]$/.test(this.companyCIF);
    },
    isFormValid() {
      if (this.role === 'admin') {
        return (
          this.isFirstNameValid &&
          this.isLastNameValid &&
          this.isPhoneValid &&
          this.isEmailValid &&
          this.isPasswordValid &&
          this.role &&
          this.companyName &&
          this.companyAddress &&
          this.isCIFValid
        );
      } else {
        return (
          this.isFirstNameValid &&
          this.isLastNameValid &&
          this.isPhoneValid &&
          this.isEmailValid &&
          this.isPasswordValid &&
          this.role
        );
      }
    }
  },
  methods: {
    async submitForm() {
      try {
        // Verificar duplicados
        const isEmailDuplicated = await this.isEmailDuplicate(this.email);
        const isPhoneDuplicated = await this.isPhoneDuplicate(this.phone);
        const isCompanyDuplicated = this.role === 'admin' ? await this.isCompanyDuplicate(this.companyName) : false;

        // Mensaje de error con campos duplicados
        let errorMessage = '';
        if (isEmailDuplicated) {
          errorMessage += '<p>Email ya está en uso.</p>';
        }
        if (isPhoneDuplicated) {
          errorMessage += '<p>Teléfono ya está en uso.</p>';
        }
        if (isCompanyDuplicated) {
          errorMessage += '<p>Nombre de empresa ya está en uso.</p>';
        }

        // Si hay duplicados, mostrar mensaje de error y salir
        if (isEmailDuplicated || isPhoneDuplicated || isCompanyDuplicated) {
          this.errorMessage = errorMessage;
          return;
        }

        // Si no hay duplicados, enviar el formulario
        const formData = {
          firstName: this.firstName,
          lastName: this.lastName,
          phone: this.phone,
          email: this.email,
          password: this.password,
          role: this.role,
          companyName: this.role === 'admin' ? this.companyName : '',
          companyAddress: this.role === 'admin' ? this.companyAddress : '',
          companyCIF: this.role === 'admin' ? this.companyCIF : ''
        };

        const response = await fetch('http://localhost/proyectofinal/register.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(formData)
        });
        // Parsear el texto a JSON
        const result = await response.json(); 

        if (result.success) {
          this.successMessage = 'Usuario registrado con éxito';
          this.errorMessage = ''; 
          this.clearForm();
          this.showSuccessModal();
        } else {
          this.errorMessage = result.message;
        }
      } catch (error) {
        console.error('Error en el formulario:', error);
        this.errorMessage = 'Error al enviar el formulario';
      }
    },
    clearForm() {
      this.firstName = '';
      this.lastName = '';
      this.phone = '';
      this.email = '';
      this.password = '';
      this.role = 'particular';
      this.companyName = '';
      this.companyAddress = '';
      this.companyCIF = '';
      this.successMessage = '';
    },
    validateNameInput(event) {
      const charCode = event.keyCode;
      const isLetter = (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122);
      const isSpace = charCode === 32;
      const isSpecialChar = [225, 233, 237, 243, 250, 241, 193, 201, 205, 211, 218, 209].includes(charCode); // áéíóúñÁÉÍÓÚÑ

      if (!isLetter && !isSpace && !isSpecialChar) {
        event.preventDefault();
      }
    },
    async isEmailDuplicate(email) {
      try {
        const response = await fetch('http://localhost/proyectofinal/check_duplicates.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ field: 'email', value: email })
        });
        const result = await response.json();
        return result.duplicate;
      } catch (error) {
        console.error('Error al verificar duplicado de correo electrónico:', error);
        return false;
      }
    },
    async isPhoneDuplicate(phone) {
      try {
        const response = await fetch('http://localhost/proyectofinal/check_duplicates.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ field: 'phone', value: phone })
        });
        const result = await response.json();
        return result.duplicate;
      } catch (error) {
        console.error('Error al verificar duplicado de teléfono:', error);
        return false;
      }
    },
    async isCompanyDuplicate(companyName) {
      try {
        const response = await fetch('http://localhost/proyectofinal/check_duplicates.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ field: 'company_name', value: companyName })
        });
        const result = await response.json();
        return result.duplicate;
      } catch (error) {
        console.error('Error al verificar duplicado de nombre de empresa:', error);
        return false;
      }
    },
    generatePassword() {
      const length = 16;
      const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+";
      let password = "";
      for (let i = 0, n = charset.length; i < length; ++i) {
        password += charset.charAt(Math.floor(Math.random() * n));
      }
      this.password = password;
    },
    togglePasswordVisibility() {
      this.showPassword = !this.showPassword;
    },
    goToLogin() {
      // Redirige a la página de inicio de sesión
      this.$router.push({ name: 'UserLogin' });
    },
    reloadPage() {
      // Recarga la página para limpiar el formulario
      location.reload();
    },
    showSuccessModal() {
      const modal = new Modal(document.getElementById('successModal'));
      modal.show();
    }
  }
};
</script>

<style scoped>
.container {
  max-width: 500px;
  margin: auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 10px;
  background-color: #f9f9f9;
}

h1 {
  text-align: center;
}

.form-group {
  margin-bottom: 20px;
}

label {
  font-weight: bold;
}

.btn-primary {
  background-color: #007bff;
  border-color: #007bff;
}

.btn-primary:hover {
  background-color: #0056b3;
  border-color: #0056b3;
}

.btn-secondary {
  background-color: #6c757d;
  border-color: #6c757d;
}

.btn-secondary:hover {
  background-color: #5a6268;
  border-color: #545b62;
}

.alert {
  margin-top: 20px;
}
</style>
