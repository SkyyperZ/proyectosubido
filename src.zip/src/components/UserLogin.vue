<template>
  <div class="container mt-5">
    <div class="row justify-content-center" v-if="!isLoggedIn">
      <div class="col-md-6">
        <div class="card shadow-lg border-0 rounded-lg">
          <div class="card-header bg-primary text-light">
            <h3 class="text-center my-3">Iniciar Sesión</h3>
          </div>
          <div class="card-body">
            <form @submit.prevent="submitForm" class="needs-validation">
              <div class="form-group mb-3">
                <label for="email" class="form-label">Email:</label>
                <input type="email" v-model="email" class="form-control" id="email" required>
              </div>
              <div class="form-group mb-3">
                <label for="password" class="form-label">Contraseña:</label>
                <div class="input-group">
                  <input :type="showPassword ? 'text' : 'password'" v-model="password" class="form-control" id="password" required>
                  <button type="button" class="btn btn-outline-secondary" @click="togglePasswordVisibility">
                    <i :class="['fa', showPassword ? 'fa-eye-slash' : 'fa-eye']"></i>
                  </button>
                </div>
              </div>
              <div v-if="errorMessage" class="alert alert-danger mt-3" role="alert">{{ errorMessage }}</div>
              <button type="submit" class="btn btn-primary w-100">Iniciar Sesión</button>
            </form>
            <div class="mt-4 text-center">
              <p>¿No tienes una cuenta?</p>
              <router-link to="/register" class="btn btn-link">Registrarse</router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-else class="text-center mt-5">
      <h3>Hola, {{ user.name }}</h3>
      <button class="btn btn-danger" @click="logout">Cerrar Sesión</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UserLogin',
  data() {
    return {
      email: '',
      password: '',
      showPassword: false,
      errorMessage: '',
      user: null
    };
  },
  computed: {
    isLoggedIn() {
      return !!this.user;
    }
  },
  methods: {
    async submitForm() {
      const formData = {
        email: this.email,
        password: this.password
      };

      try {
        const response = await fetch('http://localhost/proyectofinal/login.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(formData)
        });

        if (response.ok) {
          const data = await response.json();
          if (data.success) {
            this.user = {
              name: data.name,
              role: data.role
            };
            localStorage.setItem('user', JSON.stringify(this.user));
            this.$emit('login-success', this.user);
            this.$router.push('/');
          } else {
            this.errorMessage = data.message;
          }
        } else {
          this.errorMessage = 'Error al iniciar sesión. Por favor, Revise las credenciales, no coinciden.';
        }
      } catch (error) {
        this.errorMessage = 'Error al iniciar sesión. Por favor, Revise las credenciales, no coinciden.';
      }
    },
    togglePasswordVisibility() {
      this.showPassword = !this.showPassword;
    },
    logout() {
      this.user = null;
      localStorage.removeItem('user');
      this.$router.push('/login');
    },
    checkLoginStatus() {
      const user = localStorage.getItem('user');
      if (user) {
        this.user = JSON.parse(user);
      }
    }
  },
  created() {
    this.checkLoginStatus();
  }
};
</script>

<style scoped>

.container {
  margin-top: 50px;
}

.card {
  border-radius: 10px;
}

.card-header {
  background-color: #007bff;
  color: white;
}

.btn-primary {
  background-color: #007bff;
  border: none;
}

.btn-primary:hover {
  background-color: #0056b3;
}

.input-group-append {
  cursor: pointer;
}

.alert {
  margin-top: 20px;
}
</style>
