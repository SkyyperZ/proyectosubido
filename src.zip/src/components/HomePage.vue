<template>
  <div class="homepage container mt-5">
    <div class="header-section row mb-5 align-items-center">
      <div class="col-md-8">
        <h1 class="text-center text-md-start mb-4">¿Quieres aprender en tan solo 6 meses?</h1>
        <p class="lead text-center text-md-start">
          ¡Únete a nuestra comunidad de estudiantes exitosos! Con nuestros cursos certificados, podrás dominar habilidades clave 
          en marketing digital, programación, SEO, y manejo de redes sociales. Aprovecha esta oportunidad y transforma tu carrera profesional.
        </p>
      </div>
      <div class="col-md-4 text-center">
        <img src="https://raw.githubusercontent.com/SkyyperZ/proyectofinal/main/img_inicial.webp" alt="Learning Image" class="img-fluid rounded">
      </div>
    </div>

    <h2 class="text-center mb-4">Nuestros Cursos</h2>

    <div class="row">
      <div class="col-md-6 mb-4">
        <div class="card h-100 shadow-sm">
          <div class="card-body">
            <h5 class="card-title">Marketing Digital</h5>
            <p class="card-text">
              Aprende a crear campañas efectivas de marketing digital y lleva tu negocio al siguiente nivel.
              Nuestros cursos están diseñados para convertirte en un experto en el ámbito digital.
            </p>
            <p><strong>Certificado Oficial</strong></p>
          </div>
        </div>
      </div>
      <div class="col-md-6 mb-4">
        <div class="card h-100 shadow-sm">
          <div class="card-body">
            <h5 class="card-title">Posicionamiento SEO</h5>
            <p class="card-text">
              Domina las técnicas de SEO y mejora la visibilidad de tu sitio web en los motores de búsqueda.
              Nuestros cursos te brindarán las herramientas necesarias para destacar en el mundo online.
            </p>
            <p><strong>Certificado Oficial</strong></p>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6 mb-4">
        <div class="card h-100 shadow-sm">
          <div class="card-body">
            <h5 class="card-title">Programación</h5>
            <p class="card-text">
              Conviértete en un desarrollador profesional con nuestros cursos de programación. 
              Aprende desde los conceptos básicos hasta las tecnologías más avanzadas.
            </p>
            <p><strong>Certificado Oficial</strong></p>
          </div>
        </div>
      </div>
      <div class="col-md-6 mb-4">
        <div class="card h-100 shadow-sm">
          <div class="card-body">
            <h5 class="card-title">Manejo de Redes Sociales</h5>
            <p class="card-text">
              Aprende a gestionar y optimizar el uso de redes sociales para empresas y marcas personales. 
              Nuestros cursos te ayudarán a convertirte en un experto en redes sociales.
            </p>
            <p><strong>Certificado Oficial</strong></p>
          </div>
        </div>
      </div>
    </div>

    <div class="text-center mt-5">
      <router-link to="/products" class="btn btn-primary btn-lg">Ver Todos los Cursos</router-link>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HomePage',
};
</script>

<style scoped>
.homepage {
  background-color: #f8f9fa;
  padding: 20px;
  border-radius: 10px;
}

.header-section {
  background-color: #007bff;
  color: #fff;
  padding: 20px;
  border-radius: 10px;
}

h1 {
  color: #fff;
}

.card {
  border-radius: 10px;
  transition: transform 0.3s;
}

.card:hover {
  transform: translateY(-5px);
}

.card-title {
  color: #0056b3;
}

.card-text {
  color: #333;
}

.btn-primary {
  background-color: #007bff;
  border: none;
}

.btn-primary:hover {
  background-color: #0056b3;
}
</style>
