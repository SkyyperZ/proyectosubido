<template>
  <div class="container mt-5">
    <h2 class="text-center mb-4">Carrito de Compras</h2>
    <div v-if="!isAuthenticated" class="text-center">
      <p class="alert alert-warning">Para ver tu carrito, necesitas iniciar sesión o registrarte.</p>
      <div class="d-flex justify-content-center">
        <button class="btn btn-primary me-2" @click="redirectToLogin">Iniciar sesión</button>
        <button class="btn btn-secondary" @click="redirectToRegister">Registrarse</button>
      </div>
    </div>
    <div v-else>
      <div v-if="cart.length === 0" class="text-center">
        <p class="alert alert-warning">Tu carrito está vacío</p>
      </div>
      <div v-else>
        <div class="row mb-3 product-card" v-for="(item, index) in cart" :key="index">
          <div class="col-md-8">
            <h5 class="product-name">{{ item.name }}</h5>
            <p class="product-quantity">Cantidad: {{ item.quantity }}</p>
            <p class="product-price">Precio: {{ item.price }}</p>
          </div>
          <div class="col-md-4 text-end">
            <button class="btn btn-danger btn-sm" @click="removeFromCart(index)">Eliminar</button>
          </div>
        </div>
        <div class="row total-payment">
          <div class="col-md-8">
            <h4>Total a Pagar: {{ total }}</h4>
          </div>
          <div class="col-md-4 text-end">
            <button class="btn btn-success" @click="openPaymentForm">Pagar</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de Pago -->
    <div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header bg-primary text-light">
            <h5 class="modal-title" id="paymentModalLabel">Método de Pago</h5>
            <button type="button" class="btn-close text-light" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="row text-center mb-3">
              <div class="col-6">
                <img src="https://raw.githubusercontent.com/SkyyperZ/proyectofinal/main/Paypal_2014_logo.webp" alt="paypal" class="img-thumbnail w-100">
              </div>
              <div class="col-6">
                <img src="https://raw.githubusercontent.com/SkyyperZ/proyectofinal/main/mastercard-logo-7.webp" alt="MasterCard" class="img-thumbnail w-100">
              </div>
            </div>
            <form @submit.prevent="processPayment">
              <div class="mb-3">
                <label for="cardNumber" class="form-label">Número de Tarjeta:</label>
                <input type="text" v-model="paymentDetails.cardNumber" class="form-control" id="cardNumber" required @input="validateCardNumber">
                <div v-if="!isCardNumberValid" class="invalid-feedback d-block">Número de tarjeta inválido</div>
              </div>
              <div class="mb-3">
                <label for="expiryDate" class="form-label">Fecha de Caducidad (MM/AA):</label>
                <input type="text" v-model="paymentDetails.expiryDate" class="form-control" id="expiryDate" required @input="validateExpiryDate">
                <div v-if="!isExpiryDateValid" class="invalid-feedback d-block">Fecha de caducidad inválida</div>
              </div>
              <div class="mb-3">
                <label for="cvc" class="form-label">CVC:</label>
                <input type="text" v-model="paymentDetails.cvc" class="form-control" id="cvc" required @input="validateCVC">
                <div v-if="!isCVCValid" class="invalid-feedback d-block">CVC inválido</div>
              </div>
              <div class="mb-3">
                <label for="phone" class="form-label">Teléfono de contacto:</label>
                <input type="text" v-model="paymentDetails.phone" class="form-control" id="phone" required @input="validatePhone">
                <div v-if="!isPhoneValid" class="invalid-feedback d-block">Teléfono inválido</div>
              </div>
              <div class="mb-3">
                <label for="email" class="form-label">Email de contacto:</label>
                <input type="email" v-model="paymentDetails.email" class="form-control" id="email" required>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" v-model="paymentDetails.privacyPolicy" id="privacyPolicy" required>
                <label class="form-check-label" for="privacyPolicy">
                  Acepto la <a href="/privacy-policy.html" class="text-primary"> política de privacidad </a> de NEW ERA SHOP
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" v-model="paymentDetails.dataTreatment" id="dataTreatment" required>
                <label class="form-check-label" for="dataTreatment">
                  Acepto el <a href="/data-policy.html" class="text-primary"> tratamiento de datos </a> por parte de NEW ERA SHOP
                </label>
              </div>
              <h5 class="mt-3">Pedido:</h5>
              <ul class="list-group mb-3">
                <li class="list-group-item" v-for="item in cart" :key="item.id">{{ item.name }} - {{ item.quantity }} x {{ item.price }}</li>
              </ul>
              <h5>Total a pagar: {{ total }}</h5>
              <button type="submit" class="btn btn-primary btn-block" :disabled="!isFormValid">Realizar Pago</button>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de Login -->
    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header bg-primary text-light">
            <h5 class="modal-title" id="loginModalLabel">Inicia sesión o regístrate</h5>
            <button type="button" class="btn-close text-light" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p>Para añadir productos al carrito, necesitas iniciar sesión o registrarte.</p>
            <div class="d-flex justify-content-between">
              <button class="btn btn-primary" @click="redirectToLogin">Iniciar sesión</button>
              <button class="btn btn-secondary" @click="redirectToRegister">Registrarse</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de Pago Exitoso -->
    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header bg-success text-light">
            <h5 class="modal-title" id="successModalLabel">Pago Exitoso</h5>
            <button type="button" class="btn-close text-light" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body text-center">
            <i class="fa fa-check-circle fa-3x text-success mb-3"></i>
            <p>Su pago se ha realizado con éxito.</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Modal } from 'bootstrap';

export default {
  name: 'ShoppingCart',
  data() {
    return {
      cart: [],
      isAuthenticated: false, 
      paymentDetails: {
        cardNumber: '',
        expiryDate: '',
        cvc: '',
        phone: '',
        email: '',
        privacyPolicy: false,
        dataTreatment: false
      },
      isCardNumberValid: true,
      isExpiryDateValid: true,
      isCVCValid: true,
      isPhoneValid: true
    };
  },
  computed: {
    total() {
      return this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    },
    isFormValid() {
      return (
        this.isCardNumberValid &&
        this.isExpiryDateValid &&
        this.isCVCValid &&
        this.isPhoneValid &&
        this.paymentDetails.email &&
        this.paymentDetails.privacyPolicy &&
        this.paymentDetails.dataTreatment
      );
    }
  },
  methods: {
    loadCart() {
      if (this.isAuthenticated) {
        this.cart = JSON.parse(localStorage.getItem('cart')) || [];
      } else {
        this.cart = [];
      }
    },
    removeFromCart(index) {
      this.cart.splice(index, 1);
      localStorage.setItem('cart', JSON.stringify(this.cart));
    },
    openPaymentForm() {
      if (!this.isAuthenticated) {
        this.showLoginModal();
      } else {
        const modal = new Modal(document.getElementById('paymentModal'));
        modal.show();
      }
    },
    async processPayment() {
      try {
        const response = await fetch('http://localhost/proyectofinal/payment.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            paymentDetails: this.paymentDetails,
            cart: this.cart
          })
        });

        const text = await response.text(); 
        try {
          const result = JSON.parse(text); //parsear la respuesta como JSON
          if (response.ok && result.success) {
            const modal = Modal.getInstance(document.getElementById('paymentModal'));
            modal.hide();
            const successModal = new Modal(document.getElementById('successModal'));
            successModal.show();
            localStorage.removeItem('cart');
            this.cart = [];
          } else {
            alert('Error al realizar el pago: ' + result.message);
          }
        } catch (e) {
          alert('Error al realizar el pago: ' + text); 
        }
      } catch (error) {
        alert('Error al realizar el pago: ' + error.message);
      }
    },
    showLoginModal() {
      const modal = new Modal(document.getElementById('loginModal'));
      modal.show();
    },
    redirectToLogin() {
      this.$router.push('/login');
    },
    redirectToRegister() {
      this.$router.push('/register');
    },
    validateCardNumber() {
      const regex = /^\d{16}$/;
      this.isCardNumberValid = regex.test(this.paymentDetails.cardNumber);
    },
    validateExpiryDate() {
      const regex = /^(0[1-9]|1[0-2])\/?([0-9]{2})$/;
      this.isExpiryDateValid = regex.test(this.paymentDetails.expiryDate);
    },
    validateCVC() {
      const regex = /^\d{3,4}$/;
      this.isCVCValid = regex.test(this.paymentDetails.cvc);
    },
    validatePhone() {
      const regex = /^\d{9,15}$/;
      this.isPhoneValid = regex.test(this.paymentDetails.phone);
    },
    logout() {
      this.isAuthenticated = false;
      this.clearCart(); // Limpia el carrito al cerrar sesión
    },
    clearCart() {
      this.cart = []; // Vacía el carrito
      localStorage.removeItem('cart'); // Elimina los datos del carrito almacenados en el almacenamiento local
    }
  },
  created() {
    this.isAuthenticated = JSON.parse(localStorage.getItem('user')) !== null;
    this.loadCart();
  }
};
</script>

<style scoped>
.container {
  margin-top: 50px;
}

.text-end {
  text-align: right;
}

.product-card {
  background-color: #f8f9fa;
  border-radius: 10px;
  padding: 20px;
  margin-bottom: 15px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s, box-shadow 0.3s;
}

.product-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.product-name {
  font-weight: bold;
  font-size: 1.2em;
}

.product-quantity, .product-price {
  font-size: 1em;
  color: #555;
}

.total-payment {
  background-color: #e9ecef;
  border-radius: 10px;
  padding: 20px;
  margin-top: 20px;
}

.total-payment h4 {
  font-weight: bold;
  color: #007bff;
}

.btn-primary {
  background-color: #007bff;
  border: none;
}

.btn-primary:hover {
  background-color: #0056b3;
}

.modal-content {
  border-radius: 10px;
}

.modal-header {
  background-color: #007bff;
}

.btn-close {
  background-color: transparent;
  border: none;
  color: #fff;
}

.btn-secondary {
  background-color: #6c757d;
  border: none;
}

.btn-secondary:hover {
  background-color: #545b62;
}

.alert-warning {
  color: #856404;
  background-color: #fff3cd;
  border-color: #ffeeba;
}

.btn-danger {
  background-color: #dc3545;
  border: none;
}

.btn-danger:hover {
  background-color: #c82333;
}

.btn-success {
  background-color: #28a745;
  border: none;
}

.btn-success:hover {
  background-color: #218838;
}

.list-group-item {
  border: none;
  background-color: #f8f9fa;
  padding: 10px;
}

.fa-check-circle {
  color: #28a745;
}
</style>
