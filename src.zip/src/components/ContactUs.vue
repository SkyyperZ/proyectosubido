<template>
  <div class="container mt-5 contact-form">
    <h2 class="text-center mb-4">Contacto</h2>
    <p class="text-center mb-4">Si tienes alguna pregunta, comentario o necesitas asistencia, no dudes en ponerte en contacto con nosotros. Nuestro equipo está aquí para ayudarte y responder a todas tus inquietudes.</p>
    <form @submit.prevent="submitForm" class="shadow-lg p-4 bg-white rounded">
      <div class="mb-3">
        <label for="name" class="form-label">Nombre:</label>
        <input type="text" v-model="name" class="form-control" id="name" required>
      </div>
      <div class="mb-3">
        <label for="surname" class="form-label">Apellidos:</label>
        <input type="text" v-model="surname" class="form-control" id="surname" required>
      </div>
      <div class="mb-3">
        <label for="phone" class="form-label">Teléfono de Contacto:</label>
        <input type="text" v-model="phone" class="form-control" id="phone" required>
      </div>
      <div class="mb-3">
        <label for="email" class="form-label">Email:</label>
        <input type="email" v-model="email" class="form-control" id="email" required>
      </div>
      <div class="mb-3">
        <label for="role" class="form-label">Rol:</label>
        <select v-model="role" class="form-control" id="role" required>
          <option value="particular">Particular</option>
          <option value="empresa">Empresa</option>
        </select>
      </div>
      <div v-if="role === 'empresa'" class="mb-3">
        <label for="companyName" class="form-label">Nombre de la Empresa:</label>
        <input type="text" v-model="companyName" class="form-control" id="companyName">
      </div>
      <div class="mb-3">
        <label for="subject" class="form-label">Asunto/Motivo:</label>
        <input type="text" v-model="subject" class="form-control" id="subject" required>
      </div>
      <div class="mb-3">
        <label for="message" class="form-label">Mensaje:</label>
        <textarea v-model="message" class="form-control" id="message" rows="4" required></textarea>
      </div>
      <button type="submit" class="btn btn-primary w-100">Enviar</button>
    </form>

    <!-- Modal de éxito -->
    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header bg-primary text-light">
            <h5 class="modal-title" id="successModalLabel">Mensaje Enviado</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            Tu mensaje ha sido enviado con éxito. Nos pondremos en contacto contigo pronto.
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Modal } from 'bootstrap';

export default {
  name: 'ContactUs',
  data() {
    return {
      name: '',
      surname: '',
      phone: '',
      email: '',
      role: 'particular',
      companyName: '',
      subject: '',
      message: ''
    };
  },
  methods: {
    async submitForm() {
      const formData = {
        name: this.name,
        surname: this.surname,
        phone: this.phone,
        email: this.email,
        role: this.role,
        companyName: this.companyName,
        subject: this.subject,
        message: this.message
      };

      try {
        const response = await fetch('http://localhost/proyectofinal/contact.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(formData)
        });

        const result = await response.json();
        if (result.success) {
          this.showSuccessModal();
          this.resetForm();
        } else {
          alert('Error al enviar el mensaje: ' + result.message);
        }
      } catch (error) {
        alert('Error al enviar el mensaje: ' + error.message);
      }
    },
    resetForm() {
      this.name = '';
      this.surname = '';
      this.phone = '';
      this.email = '';
      this.role = 'particular';
      this.companyName = '';
      this.subject = '';
      this.message = '';
    },
    showSuccessModal() {
      const successModal = new Modal(document.getElementById('successModal'));
      successModal.show();
    }
  }
};
</script>

<style scoped>
.container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
}

.contact-form {
  background-color: #f9f9f9;
  border-radius: 10px;
  padding: 20px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.form-label {
  font-weight: bold;
  color: #007bff;
}

.btn-primary {
  background-color: #007bff;
  border: none;
}

.btn-primary:hover {
  background-color: #0056b3;
}

.btn-close {
  background-color: transparent;
  border: none;
}

.btn-secondary {
  background-color: #6c757d;
  border: none;
}

.btn-secondary:hover {
  background-color: #545b62;
}

input, textarea, select {
  border: 1px solid #007bff;
  border-radius: 5px;
  padding: 10px;
  font-size: 16px;
}

input:focus, textarea:focus, select:focus {
  border-color: #007bff;
  box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
  outline: none;
}

.modal-header {
  background-color: #007bff;
  color: white;
}

.modal-footer {
  border-top: 1px solid #dee2e6;
}
</style>
